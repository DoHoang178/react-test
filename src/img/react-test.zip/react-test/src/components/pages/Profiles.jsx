import React from "react";
import "./Login";

function Profifes() {
  return (
    <div>
      <h1>profile</h1>
    </div>
  );
}

export default Profifes;
