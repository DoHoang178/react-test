export const data = [
  {
    tag: "Search data",
    infomation:
      "Don’t worry if your data is very large, the Data Warehoue provides a search engine, which is useful for making it easier to find data effectively saving time.",
    image1: require('../../img/image3 1.png'),
    image2: require('../../img/Rectangle 39.png'),
  },
  {
    tag: "24 Hours Access",
    infomation:
      "Access is given 24 hours a full morning to night and meet again in the morning, giving you comfort when you need data when urgent",
    image1: require('../../img/image4.png'),
    image2: require('../../img/Rectangle 40.png'),
  },
  {
    tag: "Print Out",
    infomation:
      "Print out service gives you convenience if someday you need print data, just edit it all and just print it.",
    image1: require('../../img/image5 1.png'),
    image2: require('../../img/Rectangle 41.png'),
  },
  {
    tag: "Security Code",
    infomation:
      "Data Security is one of our best facilities. Allows for your files to be safer. The file can be secured with a code or password that you created, so only you can open the file.",
    image1: require('../../img/image6 1.png'),
    image2: require('../../img/Rectangle 42.png'),
  },
];
